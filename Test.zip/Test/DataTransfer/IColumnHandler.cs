﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Test.DataTransfer
{
    public interface IColumnHandler
    {
        object Handler(object sourceColumnValue, DataRow sourceDataRow);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Text;
using Test.DataTransfer.Mapping;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;

namespace Test.DataTransfer
{
    public class DataTransferService
    {
        private Association association;
        private Table source;
        private Table target;
        private IDbProvider sourceDbProvider;
        private IDbProvider targetDbProvider;

        /// <summary>
        /// 从数据库加载DataTable之前触发
        /// </summary>
        public event EventHandler<BeforeLoadDataTableEventArgs> BeforeLoadDataTable;
        /// <summary>
        /// 在执行insert之前触发，对于源表的每行都会触发一次
        /// </summary>
        public event EventHandler<BeforeImportEventArgs> BeforeImport;
        /// <summary>
        /// 当导入失败时触发，失败可能是执行ExecuteNonQuery或者调用column的handler时
        /// </summary>
        public event EventHandler<ImportErrorEventArgs> ImportError;

        protected virtual void OnBeforeLoadDataTable(BeforeLoadDataTableEventArgs e)
        {
            if (BeforeLoadDataTable != null)
            {
                BeforeLoadDataTable(this, e);
            }
        }

        protected virtual void OnBeforeImport(BeforeImportEventArgs e)
        {
            if (BeforeImport != null)
            {
                BeforeImport(this, e);
            }
        }

        protected virtual void OnImportError(ImportErrorEventArgs e)
        {
            if (ImportError != null)
            {
                ImportError(this, e);
            }
        }

        public DataTransferService(Association association, Table target, IDbProvider sourceDbProvider, IDbProvider targetDbProvider)
        {
            this.association = association;
            this.target = target;
            this.sourceDbProvider = sourceDbProvider;
            this.targetDbProvider = targetDbProvider;
        }

        public DataTransferService(Table source, Table target, IDbProvider sourceDbProvider, IDbProvider targetDbProvider)
        {
            this.source = source;
            this.target = target;
            this.sourceDbProvider = sourceDbProvider;
            this.targetDbProvider = targetDbProvider;
        }

        private string GetSourceTableName()
        {
            string tableName = string.Empty;
            if (this.association == null)
            {
                tableName = this.source.Name;
            }
            else
            {
                tableName = this.association.Principal.Table.Name;
            }
            return tableName;
        }

        /// <summary>
        /// 执行数据迁移操作，从源表导入到目标表
        /// </summary>
        public void Transfer()
        {
            ThrowIfNull();
            if (this.association == null)
            {
                string selectCommandText = this.source.Select;
                if (string.IsNullOrEmpty(selectCommandText))
                {
                    selectCommandText = GetSelectCommandText();
                }
                DataTable sourceDataTable = GetSourceDataTable(selectCommandText);
                DoImport(sourceDataTable, this.target);
            }
            else
            {
                string selectCommandText = GetSelectCommandTextWithJoin();
                OnBeforeLoadDataTable(new BeforeLoadDataTableEventArgs() { SelectCommandText = selectCommandText });
                DataTable sourceDataTable = GetSourceDataTable(selectCommandText);
                DoImport(sourceDataTable, target);
            }
        }

        private DataTable GetSourceDataTable(string selectCommandText)
        {
            OnBeforeLoadDataTable(new BeforeLoadDataTableEventArgs() { SelectCommandText = selectCommandText });
            string tableName = GetSourceTableName();
            TraceTool.TTrace.Debug.Send("源表" + tableName + "的select语句：", selectCommandText);
            DataTable sourceTable = sourceDbProvider.GetDataTable(selectCommandText);
            return sourceTable;
        }

        private void DoImport(DataTable sourceDataTable, Table target)
        {
            string insertCommandText = GetInsertCommandText(target);
            TraceTool.TTrace.Debug.Send("目标表：" + target.Name + "的insert语句：", insertCommandText);
            //开始执行导入
            for (var i = 0; i < sourceDataTable.Rows.Count; i++)
            {
                try
                {
                    List<IDataParameter> parameters = new List<IDataParameter>();
                    foreach (var col in target.Columns)
                    {
                        var parameterName = this.targetDbProvider.ParameterPrefix + col.Name;
                        object parameterValue = GetParameterValue(sourceDataTable, sourceDataTable.Rows[i], col);
                        var parameter = this.targetDbProvider.CreateParameter(parameterName, parameterValue);
                        parameters.Add(parameter);
                    }
                    BeforeImportEventArgs e = new BeforeImportEventArgs();
                    OnBeforeImport(e);
                    if (!e.Cancel)
                    {
                        this.targetDbProvider.ExecuteNonQuery(insertCommandText, parameters.ToArray());
                    }
                    else
                    {
                        TraceTool.TTrace.Debug.Send(string.Format("行{0}的导入被取消，目标表：" + target.Name, i));
                    }
                }
                catch (Exception ex)
                {
                    TraceTool.TTrace.Debug.Send("导入失败：" + ex.Message, ex.StackTrace);
                    ImportErrorEventArgs e = new ImportErrorEventArgs();
                    e.Exception = ex;
                    e.SourceDataRow = sourceDataTable.Rows[i];
                    e.TargetTable = target;
                    OnImportError(e);
                    if (e.Terminate)
                    {
                        break;
                    }
                }
            }
        }

        private string GetInsertCommandText(Table target)
        {
            string insert = "insert into " + this.targetDbProvider.WrapName(target.Name) + " (";
            string valuesString = string.Empty;
            //通过目标表组装insert语句
            foreach (var item in target.Columns)
            {
                insert += this.targetDbProvider.WrapName(item.Name) + ",";
                valuesString += this.targetDbProvider.ParameterPrefix + item.Name + ",";
            }
            insert = insert.TrimEnd(',');
            insert += ") values (" + valuesString.TrimEnd(',') + ")";
            return insert;
        }

        private object GetParameterValue(DataTable sourceTable, DataRow sourceDataRow, Column col)
        {
            object parameterValue = null;
            object sourceColumnValue = null;
            if (col.Value != null)
            {
                parameterValue = col.Value;
            }
            else
            {
                col.MapName = col.MapName ?? col.Name;
                if (!string.IsNullOrEmpty(col.MapName))
                {
                    if (sourceTable.Columns.Contains(col.MapName))
                    {
                        sourceColumnValue = sourceDataRow[col.MapName];
                    }
                }
                if (col.Handler != null)
                {
                    parameterValue = col.Handler.Handler(sourceColumnValue, sourceDataRow);
                }
                else
                {
                    if (sourceTable.Columns.Contains(col.MapName))
                    {
                        parameterValue = sourceDataRow[col.MapName];
                    }
                    else
                    {
                        string tableName = GetSourceTableName();
                        throw new DataTransferException(string.Format("源表{0}中不存在字段“{1}”，目标表：{2}", tableName, col.MapName, this.target.Name));
                    }
                }
            }
            return parameterValue;
        }

        private string GetSelectCommandText()
        {
            //通过源表配置，组装select语句
            string select = "select ";
            foreach (var item in this.source.Columns)
            {
                select += this.sourceDbProvider.WrapName(item.Name) + ",";
            }
            select = select.TrimEnd(',');
            select += " from " + this.sourceDbProvider.WrapName(this.source.Name);
            if (!string.IsNullOrEmpty(this.source.Alias))
            {
                select += " " + this.source.Alias;
            }
            return select;
        }

        private string GetSelectCommandTextWithJoin()
        {
            string select = "select ";
            string joinString = string.Empty;
            string principalAlias = this.association.Principal.Table.Name;
            if (!string.IsNullOrEmpty(this.association.Principal.Table.Alias))
            {
                principalAlias = this.association.Principal.Table.Alias;
            }
            foreach (var item in this.association.Principal.Table.Columns)
            {
                select += this.sourceDbProvider.WrapName(principalAlias) + "." + this.sourceDbProvider.WrapName(item.Name) + ",";
            }
            foreach (var item in this.association.Dependents)
            {
                var alias = item.Table.Name;
                if (!string.IsNullOrEmpty(item.Table.Alias))
                {
                    alias = item.Table.Alias;
                }
                joinString += " " + (item.Join ?? "inner join") + " " + this.sourceDbProvider.WrapName(item.Table.Name);
                if (!string.IsNullOrEmpty(item.Table.Alias))
                {
                    joinString += " " + item.Table.Alias;
                }
                joinString += " on " + this.sourceDbProvider.WrapName(alias) + "." + this.sourceDbProvider.WrapName(item.ColumnName);
                joinString += "=" + this.sourceDbProvider.WrapName(principalAlias) + "." + this.sourceDbProvider.WrapName(this.association.Principal.ColumnName);
                foreach (var col in item.Table.Columns)
                {
                    select += this.sourceDbProvider.WrapName(alias) + "." + this.sourceDbProvider.WrapName(col.Name) + ",";
                }
            }
            select = select.TrimEnd(',');
            select += " from " + this.targetDbProvider.WrapName(this.association.Principal.Table.Name);
            if (!string.IsNullOrEmpty(this.association.Principal.Table.Alias))
            {
                select += " " + this.association.Principal.Table.Alias;
            }
            select += joinString;
            return select;
        }

        private void ThrowIfNull()
        {
            if (this.sourceDbProvider == null)
            {
                throw new DataTransferException("sourceDbProvider不允许为空");
            }
            if (this.targetDbProvider == null)
            {
                throw new DataTransferException("targetDbProvider不允许为空");
            }
            if (this.target == null)
            {
                throw new DataTransferException("target不允许为空");
            }
            if (this.association == null)
            {
                if (this.source == null)
                {
                    throw new DataTransferException("source不允许为空");
                }
            }
            else
            {
                if (this.association.Principal == null)
                {
                    throw new DataTransferException("association.Principal 不允许为空");
                }
                else if (this.association.Dependents == null || this.association.Dependents.Count == 0)
                {
                    throw new DataTransferException("association.Dependents 不允许为空或记录为零");
                }
            }
        }
    }
}

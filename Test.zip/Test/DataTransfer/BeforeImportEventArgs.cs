﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Test.DataTransfer
{
    public class BeforeImportEventArgs : EventArgs
    {
        public DataRow SourceDataRow { get; set; }
        public string InsertCommandText { get; set; }
        public IEnumerable<IDataParameter> Parameters { get; set; }
        /// <summary>
        /// 为true表示取消当前行的导入
        /// </summary>
        public bool Cancel { get; set; }
    }
}

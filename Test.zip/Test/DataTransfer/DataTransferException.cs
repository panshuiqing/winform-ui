﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test.DataTransfer
{
    public class DataTransferException : Exception
    {
        
        public DataTransferException()
            :base("数据映射异常")
        {

        }

        public DataTransferException(string message)
            : base(message)
        {
        }

        public DataTransferException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}

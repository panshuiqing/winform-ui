﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test.DataTransfer.Mapping
{
    /// <summary>
    /// 表映射对象
    /// </summary>
    public class Table
    {
        public Table()
        {
            this.Columns = new List<Column>();
        }

        /// <summary>
        /// 表名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 表别名
        /// </summary>
        public string Alias { get; set; }
        /// <summary>
        /// select查询语句
        /// </summary>
        public string Select { get; set; }
        /// <summary>
        /// 字段集合
        /// </summary>
        public IList<Column> Columns { get; private set; }
    }
}

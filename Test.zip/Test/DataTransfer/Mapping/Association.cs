﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test.DataTransfer.Mapping
{
    /// <summary>
    /// 表关联对象，仅表示源表的关系
    /// </summary>
    public class Association
    {
        public Association()
        {
            this.Dependents = new List<AssociationItem>();
        }

        /// <summary>
        /// 关联主体
        /// </summary>
        public AssociationItem Principal { get; set; }
        /// <summary>
        /// 关联依赖项
        /// </summary>
        public IList<AssociationItem> Dependents { get; set; }
    }
}

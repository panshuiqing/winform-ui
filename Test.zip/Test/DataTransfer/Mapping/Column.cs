﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test.DataTransfer.Mapping
{
    /// <summary>
    /// 字段映射
    /// </summary>
    public class Column
    {
        /// <summary>
        /// 字段名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 对应源表字段名称
        /// </summary>
        public string MapName { get; set; }
        /// <summary>
        /// 字段常量值
        /// </summary>
        public object Value { get; set; }
        /// <summary>
        /// 所属表
        /// </summary>
        public Table Table { get; set; }
        /// <summary>
        /// IColumnHandler的实例
        /// </summary>
        public IColumnHandler Handler { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test.DataTransfer.Mapping
{
    /// <summary>
    /// 关联项
    /// </summary>
    public class AssociationItem
    {
        /// <summary>
        /// Table
        /// </summary>
        public Table Table { get; set; }
        /// <summary>
        /// 关联字段名称
        /// </summary>
        public string ColumnName { get; set; }
        /// <summary>
        /// 关联值 inner或left
        /// </summary>
        public string Join { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Test.DataTransfer.Mapping;

namespace Test.DataTransfer
{
    public class ImportErrorEventArgs : EventArgs
    {
        public Exception Exception { get; set; }
        /// <summary>
        /// 是否终止
        /// </summary>
        public bool Terminate { get; set; }
        /// <summary>
        /// 目标表映射
        /// </summary>
        public Table TargetTable { get; set; }
        /// <summary>
        /// 当前导入的行
        /// </summary>
        public DataRow SourceDataRow { get; set; }
    }
}

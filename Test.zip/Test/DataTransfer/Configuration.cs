﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using System.Xml.Schema;
using Test.DataTransfer.Mapping;

namespace Test.DataTransfer
{
    public class Configuration
    {
        private const string xsdName = "Test.DataTransfer.DataTransfer.xsd";

        private string mappingFile;
        private Association association;
        private IList<Table> sourceTables;
        private Table targetTable;

        public Configuration LoadMappingFile(string mappingFile)
        {
            this.mappingFile = mappingFile;
            if (!File.Exists(this.mappingFile))
            {
                throw new DataTransferException("xml映射文件不存在，" + mappingFile);
            }
            try
            {
                var document = XDocument.Load(mappingFile);
                ValidateSchema(document);
                var elSources = document.Element("mapping").Element("source").Elements("table");
                var elTarget = document.Element("mapping").Element("target").Element("table");
                var elAssociation = document.Element("mapping").Element("source").Element("association");
                sourceTables = new List<Table>();
                targetTable = CreateTable(elTarget);
                FillSourceTables(elSources, sourceTables);
                association = CreateAssociation(elAssociation, sourceTables);
            }
            catch (Exception ex)
            {
                TraceTool.TTrace.Error.Send("映射文件格式不正确，" + mappingFile, ex.StackTrace);
                throw new DataTransferException("映射文件格式不正确，" + mappingFile, ex);
            }
            return this;
        }

        private void SetPropertyValue(object obj, string propertyName, XAttribute attr)
        {
            if (obj != null && attr != null && propertyName != null)
            {
                var property = obj.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (property != null)
                {
                    if (property.PropertyType == typeof(bool))
                    {
                        if (attr.Value != null)
                        {
                            property.SetValue(obj, attr.Value == "1" || attr.Value.ToLower() == "true", null);
                        }
                    }
                    else
                    {
                        property.SetValue(obj, attr.Value, null);
                    }
                }
            }
        }

        public DataTransferService BuildDataTransferService(IDbProvider sourceDbProvider, IDbProvider targetDbProvider)
        {
            if (association != null)
            {
                return new DataTransferService(association, targetTable, sourceDbProvider, targetDbProvider);
            }
            else
            {
                return new DataTransferService(sourceTables[0], targetTable, sourceDbProvider, targetDbProvider);
            }
        }

        private void ValidateSchema(XDocument document)
        {
            XmlSchemaSet schemaSet = new XmlSchemaSet();
            var schema = GetSchema();
            schemaSet.Add(schema);
            document.Validate(schemaSet, (sender, e) =>
            {
                TraceTool.TTrace.Error.Send("映射文件格式不正确，" + mappingFile, e.Message);
                throw new DataTransferException("映射文件格式不正确：" + e.Message + "，" + mappingFile, e.Exception);
            }, true);
        }

        private XmlSchema GetSchema()
        {
            Assembly executingAssembly = Assembly.GetExecutingAssembly();
            using (Stream resourceStream = executingAssembly.GetManifestResourceStream(xsdName))
            {
                return XmlSchema.Read(resourceStream, null);
            }
        }

        private Association CreateAssociation(XElement elAssociation, IList<Table> sourceTables)
        {
            Association association = null;
            if (elAssociation != null)
            {
                association = new Association();
                var elPrincipal = elAssociation.Element("principal");
                var elDependents = elAssociation.Elements("dependent");
                association.Principal = new AssociationItem();
                SetPropertyValue(association.Principal, "columnName", elPrincipal.Attribute("columnName"));
                SetPropertyValue(association.Principal, "join", elPrincipal.Attribute("join"));
                var tableName = elPrincipal.Attribute("tableName").Value;
                var table = sourceTables.FirstOrDefault(t => string.Compare(t.Name, tableName, true) == 0);
                association.Principal.Table = table;
                if (table == null)
                {
                    throw new DataTransferException(string.Format("association的principal节点配置错误，找不到name为“{0}”的table节点，", association.Principal.Table.Name) + mappingFile);
                }
                foreach (var item in elDependents)
                {
                    AssociationItem dependent = new AssociationItem();
                    tableName = item.Attribute("tableName").Value;
                    table = sourceTables.FirstOrDefault(t => string.Compare(t.Name, tableName, true) == 0);
                    dependent.Table = table;
                    if (table == null)
                    {
                        throw new DataTransferException(string.Format("association的dependent节点配置错误，找不到name为“{0}”的table节点，", dependent.Table.Name) + mappingFile);
                    }
                    SetPropertyValue(dependent, "columnName", item.Attribute("columnName"));
                    SetPropertyValue(dependent, "join", item.Attribute("join"));
                    association.Dependents.Add(dependent);
                }
            }
            return association;
        }

        private void FillSourceTables(IEnumerable<XElement> elSources, IList<Table> sourceTables)
        {
            foreach (var item in elSources)
            {
                Table table = CreateTable(item);
                if (sourceTables.Any(t => string.Compare(t.Name, table.Name, true) == 0))
                {
                    throw new DataTransferException(string.Format("table节点的name属性值“{0}”重复，", table.Name) + mappingFile);
                }
                sourceTables.Add(table);
            }
        }

        private Table CreateTable(XElement element)
        {
            Table table = new Table();
            table.Name = element.Attribute("name").Value;
            SetPropertyValue(table, "select", element.Attribute("select"));
            SetPropertyValue(table, "alias", element.Attribute("alias"));
            foreach (var col in element.Elements("column"))
            {
                var column = new Column();
                SetPropertyValue(column, "name", col.Attribute("name"));
                SetPropertyValue(column, "mapName", col.Attribute("mapName"));
                SetPropertyValue(column, "value", col.Attribute("value"));
                SetColumnHandler(table, col, column);
                table.Columns.Add(column);
            }
            return table;
        }

        private void SetColumnHandler(Table table, XElement col, Column column)
        {
            if (col.Attribute("handler") != null && !string.IsNullOrEmpty(col.Attribute("handler").Value))
            {
                var handler = col.Attribute("handler").Value;
                var type = Type.GetType(handler);
                if (type == null)
                {
                    try
                    {
                        var className = handler.Split(',')[0];
                        var assemblyName = handler.Split(',')[1];
                        type = Assembly.LoadFrom(assemblyName).GetType(className);
                    }
                    catch (Exception ex)
                    {
                        TraceTool.TTrace.Error.Send(ex.Message, ex.StackTrace);
                        throw new DataTransferException(string.Format("handler值格式错误，在table：{0}，column：{1}，", table.Name, column.Name) + mappingFile, ex);
                    }
                }
                if (type == null)
                {
                    throw new DataTransferException(string.Format("找不到类型：{0}，在table：{1}，column：{2}，", handler, table.Name, column.Name) + mappingFile);
                }
                if (type.IsClass && typeof(IColumnHandler).IsAssignableFrom(type))
                {
                    column.Handler = (IColumnHandler)Activator.CreateInstance(type);
                }
                else
                {
                    throw new DataTransferException(string.Format("不是有效的IColumnHandler类型，在table：{1}，column：{2}，", handler, table.Name, column.Name) + mappingFile);
                }
            }
        }
    }
}

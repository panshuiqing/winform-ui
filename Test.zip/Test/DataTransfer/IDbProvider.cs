﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Test.DataTransfer
{
    public interface IDbProvider
    {
        DataTable GetDataTable(string commandText, params IDataParameter[] parameters);
        int ExecuteNonQuery(string commandText, params IDataParameter[] parameters);
        IDataParameter CreateParameter(string parameterName, object value);
        /// <summary>
        /// 组装表或字段名称，比如Name变成[Name]，避免关键字问题
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns></returns>
        string WrapName(string name);
        /// <summary>
        /// 参数前缀符，Oracle为:，Sql Server和Access为@
        /// </summary>
        string ParameterPrefix { get; }
    }
}

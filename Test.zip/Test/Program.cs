﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Teleware.HBYDBP.Business.DataTransfer;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Configuration cfg = new Configuration();
            var sourceDbProvider = new AccessProvider();
            var targetDbProvider = new SqlServerProvider();
            DataTransferService service = null;
            //1、原表和目标表的表名称和字段一样
            //service = cfg.LoadMappingFile("CLASS_AREA_DTL2.xml").BuildDataTransferService(sourceDbProvider, targetDbProvider);
            //service.BeforeLoadDataTable += service_BeforeLoadDataTable;
            //service.BeforeImport += service_BeforeImport;
            //service.ImportError += service_ImportError;
            //service.Transfer();

            //2、字段名称映射
            //service = cfg.LoadMappingFile("CLASS_AREA_DTL2_1.xml").BuildDataTransferService(sourceDbProvider, targetDbProvider);
            //service.BeforeLoadDataTable += service_BeforeLoadDataTable;
            //service.BeforeImport += service_BeforeImport;
            //service.ImportError += service_ImportError;
            //service.Transfer();

            //3、使用column的value属性，设置常量值
            //service = cfg.LoadMappingFile("CLASS_AREA_DTL2_2.xml").BuildDataTransferService(sourceDbProvider, targetDbProvider);
            //service.BeforeLoadDataTable += service_BeforeLoadDataTable;
            //service.BeforeImport += service_BeforeImport;
            //service.ImportError += service_ImportError;
            //service.Transfer();

            //4、使用column的handler属性，设置特殊值
            service = cfg.LoadMappingFile("CLASS_AREA_DTL2_3.xml").BuildDataTransferService(sourceDbProvider, targetDbProvider);
            service.BeforeLoadDataTable += service_BeforeLoadDataTable;
            service.BeforeImport += service_BeforeImport;
            service.ImportError += service_ImportError;
            service.Transfer();

            //5、使用join查询源表
            //service = cfg.LoadMappingFile("CLASS_AREA_DTL2_3.xml").BuildDataTransferService(sourceDbProvider, targetDbProvider);
            //service.BeforeLoadDataTable += service_BeforeLoadDataTable;
            //service.BeforeImport += service_BeforeImport;
            //service.ImportError += service_ImportError;
            //service.Transfer();

            //5、使用配置的select查询源表
            //service = cfg.LoadMappingFile("CLASS_AREA_DTL2_4.xml").BuildDataTransferService(sourceDbProvider, targetDbProvider);
            //service.BeforeLoadDataTable += service_BeforeLoadDataTable;
            //service.BeforeImport += service_BeforeImport;
            //service.ImportError += service_ImportError;
            //service.Transfer();

            Console.Read();
        }

        static void service_ImportError(object sender, ImportErrorEventArgs e)
        {
            //导入失败后的处理
            Console.WriteLine(e.Exception.Message);
        }

        static void service_BeforeImport(object sender, BeforeImportEventArgs e)
        {
            Console.WriteLine("对目标表执行insert前触发事件，可以取消insert的执行");
        }

        static void service_BeforeLoadDataTable(object sender, BeforeLoadDataTableEventArgs e)
        {
            Console.WriteLine("对原表执行select前触发事件，可以修改查询的sql语句，添加where等");
        }

    }

    #region 测试数据迁移代码

    public class CADD_ID_Handler : IColumnHandler
    {
        public object Handler(object sourceColumnValue, DataRow sourceDataRow)
        {
            Console.WriteLine(sourceColumnValue);
            return "处理后的值";
        }
    }

    public class SqlServerProvider : IDbProvider
    {
        private string connectionString = "Data Source=.;Initial Catalog=test;uid=sa;pwd=123;";

        private SqlConnection OpenConnection()
        {
            var connection = new SqlConnection(this.connectionString);
            connection.Open();
            return connection;
        }

        public IDataParameter CreateParameter(string parameterName, object value)
        {
            return new SqlParameter(parameterName, value);
        }

        public int ExecuteNonQuery(string commandText, params System.Data.IDataParameter[] parameters)
        {
            int ret = 0;
            using (var connection = OpenConnection())
            {
                SqlCommand cmd = new SqlCommand(commandText, connection);
                cmd.Parameters.AddRange(parameters);
                ret = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                connection.Close();
            }
            return ret;
        }

        public DataTable GetDataTable(string commandText, params System.Data.IDataParameter[] parameters)
        {
            SqlDataAdapter adapter = new SqlDataAdapter(commandText, connectionString);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        public string ParameterPrefix
        {
            get { return "@"; }
        }

        public string WrapName(string name)
        {
            return "[" + name + "]";
        }
    }

    public class AccessProvider : IDbProvider
    {
        private string connectionString = @"Provider=Microsoft.Jet.OleDb.4.0;Data Source=test.mdb;";

        private OleDbConnection OpenConnection()
        {
            var connection = new OleDbConnection(this.connectionString);
            connection.Open();
            return connection;
        }

        public IDataParameter CreateParameter(string parameterName, object value)
        {
            return new OleDbParameter(parameterName, value);
        }

        public int ExecuteNonQuery(string commandText, params System.Data.IDataParameter[] parameters)
        {
            int ret = 0;
            using (var connection = OpenConnection())
            {
                OleDbCommand cmd = new OleDbCommand(commandText, connection);
                cmd.Parameters.AddRange(parameters);
                ret = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                connection.Close();
            }
            return ret;
        }

        public DataTable GetDataTable(string commandText, params System.Data.IDataParameter[] parameters)
        {
            OleDbDataAdapter adapter = new OleDbDataAdapter(commandText, connectionString);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        public string ParameterPrefix
        {
            get { return "@"; }
        }

        public string WrapName(string name)
        {
            return "[" + name + "]";
        }
    }

    #endregion
}
